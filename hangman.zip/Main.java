package hangman;

import java.util.Scanner;

public class Main {
	static Scanner b = new Scanner (System.in);
	static Hangman hangman;
	public static void main(String[] args) {
		char choice = ' ';
		
		while (choice != '0') {
			System.out.println("\nChoose an option below");
			System.out.println("1. Start game");
			System.out.println("0. Exit");
			System.out.println("---------------------");
			System.out.print("Enter your choice: ");
			choice = b.next().charAt(0);
			switch (choice){
				case '1': 
					hangman = new Hangman("hangman.txt", 4);
					hangman.run();
					break;
				case '0':
					System.out.println("Leaving so soon.");
					break;
				default:
					System.out.println("Invalid option. ");
		}
		}
		
	}
}
