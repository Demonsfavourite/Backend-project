package hangman;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

public class WordList{
	private Scanner reader;
	private String filename;
	private int numberOfLines;
	private ArrayList<String> contentAsArray;

	public WordList(String filename){
		this.filename = filename;
		contentAsArray = placeContentIntoArray();
		numberOfLines = contentAsArray.size();
	}
	
	private ArrayList<String> placeContentIntoArray(){
		ArrayList<String> contents = new ArrayList<String>();
		try {
			reader = new Scanner(new File(this.filename));
		} catch (FileNotFoundException e) {
			System.out.println("File not found: " + filename);
			return null;
		}
		while (reader.hasNext()){
			contents.add(reader.nextLine());
		}
		return contents;
	}

	public String getRandomLine(){
		return contentAsArray.get((int)(Math.random() * numberOfLines));
	}

	public String getLine(int lineNumber){
		return contentAsArray.get(lineNumber);
	}

	public int getNumberOfLines(){
		return numberOfLines;
	}

	public ArrayList<String> getContentAsArray(){
		return contentAsArray;
	}

	public void printAll(){
		for (String line : contentAsArray){
			System.out.println(line);
		}
	}
}